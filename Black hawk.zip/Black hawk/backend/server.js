const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const multer = require('multer');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads'))); // Serve profile pictures

// Multer setup for profile picture uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  },
});
const upload = multer({ storage });

// In-memory user and friend data (for simplicity)
let users = [];
let friendRequests = [];
let messages = {};
let blockedUsers = {};

// API: Upload profile picture
app.post('/upload-profile', upload.single('profilePic'), (req, res) => {
  const filePath = `/uploads/${req.file.filename}`;
  res.json({ filePath });
});

// API: Register a new user
app.post('/register', (req, res) => {
  const { name, email } = req.body;
  const id = users.length + 1;
  const newUser = { id, name, email, profilePic: '', contacts: [], blockedUsers: [] };
  users.push(newUser);
  res.status(201).json(newUser);
});

// API: Search for users by name
app.get('/search', (req, res) => {
  const query = req.query.name.toLowerCase();
  const foundUsers = users.filter(user => user.name.toLowerCase().includes(query));
  res.json(foundUsers);
});

// API: Send a friend request
app.post('/friend-request', (req, res) => {
  const { senderId, receiverId } = req.body;
  if (!friendRequests.find(req => req.senderId === senderId && req.receiverId === receiverId)) {
    friendRequests.push({ senderId, receiverId });
  }
  res.status(200).json({ message: 'Friend request sent!' });
});

// API: Accept friend request
app.post('/accept-request', (req, res) => {
  const { senderId, receiverId } = req.body;
  friendRequests = friendRequests.filter(req => !(req.senderId === senderId && req.receiverId === receiverId));

  const sender = users.find(user => user.id === senderId);
  const receiver = users.find(user => user.id === receiverId);

  sender.contacts.push(receiverId);
  receiver.contacts.push(senderId);

  res.status(200).json({ message: 'Friend request accepted!' });
});

// API: Block a user
app.post('/block-user', (req, res) => {
  const { blockerId, blockedId } = req.body;
  const blocker = users.find(user => user.id === blockerId);
  if (!blocker.blockedUsers.includes(blockedId)) {
    blocker.blockedUsers.push(blockedId);
  }
  res.status(200).json({ message: 'User blocked.' });
});

// API: Unblock a user
app.post('/unblock-user', (req, res) => {
  const { blockerId, blockedId } = req.body;
  const blocker = users.find(user => user.id === blockerId);
  blocker.blockedUsers = blocker.blockedUsers.filter(id => id !== blockedId);
  res.status(200).json({ message: 'User unblocked.' });
});

// Real-time Chat & Video Call setup with Socket.io
io.on('connection', (socket) => {
  console.log('A user connected:', socket.id);

  // Store the user's socket id
  socket.on('registerUser', (userId) => {
    socket.userId = userId;
    console.log(`User ${userId} registered with socket ID ${socket.id}`);
  });

  // Handle friend search
  socket.on('searchUsers', (query) => {
    const foundUsers = users.filter(user => user.name.toLowerCase().includes(query.toLowerCase()));
    socket.emit('usersFound', foundUsers);
  });

  // Handle sending messages
  socket.on('sendMessage', (message) => {
    const { senderId, receiverId, content } = message;
    if (!messages[receiverId]) {
      messages[receiverId] = [];
    }
    messages[receiverId].push({ senderId, content });
    io.to(receiverId).emit('message', { senderId, content });
  });

  // Video call signaling
  socket.on('callUser', (data) => {
    io.to(data.userToCall).emit('callUser', {
      signal: data.signalData,
      from: data.from,
      name: data.name,
    });
  });

  socket.on('answerCall', (data) => {
    io.to(data.to).emit('callAccepted', data.signal);
  });

  // Disconnect
  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

// Start server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server is running on port ${PORT}`));
